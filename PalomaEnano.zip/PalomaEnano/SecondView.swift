import SwiftUI

struct SecondView: View {
    // Variable para guardar el nombre que escriba el usuario
    @State var userName: String = ""
    
    var body: some View {
        VStack(spacing: 40) {
            
            Text("Reseñas de Películas")
                .font(.largeTitle)
                .bold()
                .multilineTextAlignment(.center)
            
            // Campo de texto basado en la estructura de tu ejemplo
            HStack {
                Image(systemName: "person.circle.fill")
                    .font(.system(size: 34))
                
                TextField("Escribe tu nombre aquí", text: $userName)
                
                // Botón para borrar el texto (opcional, como en tu ejemplo)
                if !userName.isEmpty {
                    Button(action: {
                        userName = ""
                    }) {
                        Image(systemName: "xmark.circle")
                            .font(.system(size: 30))
                            .foregroundColor(.black)
                    }
                }
            }
            .padding()
            .background(Color.gray.opacity(0.3)) // Gris ligeramente transparente para que se vea bien
            .clipShape(RoundedRectangle(cornerRadius: 30))
            .padding(.horizontal)
            
            // Botón "Comenzar" basado en tu ejemplo
            Button {
                // Aquí va la acción cuando el usuario presiona el botón
                print("El usuario \(userName) quiere comenzar")
            } label: {
                Text("Comenzar")
                    .padding()
                    .font(.title2)
                    .bold()
                    .foregroundStyle(.white) // Letras blancas
                    .background(.blue) // Fondo azul para resaltar
                    .clipShape(RoundedRectangle(cornerRadius: 15))
            }
        }
    }
}

#Preview {
    SecondView()
}
