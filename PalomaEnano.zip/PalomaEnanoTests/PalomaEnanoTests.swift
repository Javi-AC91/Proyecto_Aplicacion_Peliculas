//
//  PalomaEnanoTests.swift
//  PalomaEnanoTests
//
//  Created by Facultad de Contaduría y Administración on 25/09/26.
//

import Testing
@testable import PalomaEnano

struct PalomaEnanoTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
        // Swift Testing Documentation
        // https://developer.apple.com/documentation/testing
    }

}
